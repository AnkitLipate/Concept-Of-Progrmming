package com.app;

public class Rectangle extends Shape {
	private int h,b;
	public Rectangle()
	{
		System.out.println("--Rectangle class default constr-----");
	}

	@Override
	public void area() {
		 System.out.println("Rectangle class Area");
		 //Lab Task:Calculate Area of rectangle
		
	}

}
