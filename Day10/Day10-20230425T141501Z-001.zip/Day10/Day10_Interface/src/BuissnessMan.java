
public class BuissnessMan implements Taxable{

	@Override
	public void payTax() {
		System.out.println("BuissnessMan paying tax");
		
	}

}
