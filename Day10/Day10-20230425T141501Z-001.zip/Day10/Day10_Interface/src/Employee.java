
public class Employee {

	public void dispalay()
	{
		System.out.println("---display emp details---");
	}
}
