package com.app;

public class A  implements Interface2 {

	@Override
	public void display() {
	 System.out.println("Interface 1 method");
		
	}

	@Override
	public void accept() {
		// TODO Auto-generated method stub
		System.out.println("Interface 2 method");
	}

}
