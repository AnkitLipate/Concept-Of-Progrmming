package com.app;

public interface Interface1 {

	void display();
}
