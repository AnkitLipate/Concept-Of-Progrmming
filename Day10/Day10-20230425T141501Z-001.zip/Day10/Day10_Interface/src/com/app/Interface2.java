package com.app;
//one interface can extends another interface
public interface Interface2  extends Interface1{
void accept();
}
