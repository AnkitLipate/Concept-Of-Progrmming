package com.app;

public class Test {
public static void main(String[] args) {
	
	A a=new A();
	a.accept();
	a.display();
	
}
}
