package com.app;

public enum Category {
OIL,GRAINS,RICE,BEKARY
}
