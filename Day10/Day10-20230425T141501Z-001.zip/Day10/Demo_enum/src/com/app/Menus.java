package com.app;

public enum Menus {

	tea,coffee,burger,pizza,maggy,juice;
}
