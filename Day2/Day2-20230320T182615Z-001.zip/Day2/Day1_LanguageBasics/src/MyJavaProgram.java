
public class MyJavaProgram {

	public static void main(String[] args) {
		 
		
		//in c :printf();
		
		//in cpp: cout<<
		
		//in java
		
		System.out.println("Welcome To JAVA");
		
		
		
		

	}

}
