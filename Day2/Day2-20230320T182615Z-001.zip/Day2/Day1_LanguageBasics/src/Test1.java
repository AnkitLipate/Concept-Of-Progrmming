
public class Test1 {

	public static void main(String[] args) {
		 
//		System.out.println("Enter No1");
//		System.out.println("Enter  No2");
		
		int a=10;
		int b=40;
		int c;
		c=a+b;
		
		System.out.println(c);
		System.out.println("Add="+c);
		System.out.println("Add="+(a+b));		
		System.out.println(a+"+"+b+"="+c);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		 
	}

}
