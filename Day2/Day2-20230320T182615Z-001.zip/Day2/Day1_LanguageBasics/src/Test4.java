
public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		byte b1=100;
		byte b2=100;
		
		short s1=b1;//converting byte---->short----->int   
		
		int b3=s1;//implicit
		
		long l1=b3;
		float f=l1;
		
		short s2=(short) b3;//explicit
		
		char c=65;
		System.out.println(c);
		char a='C';
		System.out.println((int)a);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
