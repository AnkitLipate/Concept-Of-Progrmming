import java.util.Scanner;

public class TestMathOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//menu
		int no1,no2;
		Scanner sc=new Scanner(System.in);
		System.out.println("No1 No2");
		no1=sc.nextInt();
		no2=sc.nextInt();
		int c=no1+no2;
		System.out.println("Add="+c);
		
		System.out.println("No1 No2");
		no1=sc.nextInt();
		no2=sc.nextInt();
		  c=no1+no2;
		System.out.println("Add="+c);
		
		
	}

}
