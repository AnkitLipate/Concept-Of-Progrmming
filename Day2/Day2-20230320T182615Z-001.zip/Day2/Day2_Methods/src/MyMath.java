
public class MyMath {
	// BL only

	// method to say hello

	public void sayHello() {
		System.out.println("welcome To Methods Demo");
		System.out.println("----------------------");
	 
	
	}
	
	//method2
	public void display(String name)
	{
		System.out.println("Welcome "+name);
	}

	//method
	public int getScore()
	{
		System.out.println("----inside getScore----");
		return 70;
	}
	
	//method
	public String getCapital(String state)
	{
		System.out.println("-----inside GetCapital-----");
		return "Mumbai";
	}
	
	
	
	public void add()
	{
	int a=10,b=40;
	System.out.println("Addition="+(a+b));
	}
	
	public void sum(int a,int b)
	{
		int c=a+b;
		System.out.println("Sum ="+c);
	}
	public int max(int i,int j)
	{
		if(i>j)
			return i;
		else
			return j;
	}
	
	
	public void isPrime(int num)
	{
		//BL
	}
	
	public void factorial(int num)
	{
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
