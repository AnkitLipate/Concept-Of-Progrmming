package pkgPayroll;
//bydeault package level access specifier is default
//default are accessible inside package only,outside package default are private

   class ImpClass {
	   
	   private int privateVariable;//insdie class
	   public int publicVariable;//everywhere
	   int defaultVariable;//outside class but only inside package

	   //methods
	   //getters and setters
}
