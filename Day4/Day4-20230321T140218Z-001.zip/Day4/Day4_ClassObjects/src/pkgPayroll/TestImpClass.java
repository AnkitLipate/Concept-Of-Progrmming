package pkgPayroll;

public class TestImpClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ImpClass imp=new ImpClass();
		imp.defaultVariable=20;
		imp.publicVariable=890;
		
		Employee e=new  Employee();
		e.age=56;
	}

}
