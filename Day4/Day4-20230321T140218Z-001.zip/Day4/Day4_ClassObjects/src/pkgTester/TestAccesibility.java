package pkgTester;
import pkgPayroll.Employee;//only public are accessible outside pkg


public class TestAccesibility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
	}

}
