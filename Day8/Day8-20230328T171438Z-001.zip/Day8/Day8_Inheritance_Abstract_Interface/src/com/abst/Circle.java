package com.abst;
//Parent :Shape :abstract class,having  area() abstract method
public class Circle extends Shape {
//redius
	@Override
	public void area() {
		System.out.println("Area of Circle");
		
	}

}




