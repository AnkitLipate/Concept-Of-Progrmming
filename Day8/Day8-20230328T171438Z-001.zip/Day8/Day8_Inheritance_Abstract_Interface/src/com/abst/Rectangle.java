package com.abst;

public  class Rectangle extends Shape {

	@Override
	public void area() {
		System.out.println("Area of Reactangle");
		
	}

}
