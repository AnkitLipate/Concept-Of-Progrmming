package com.abst;

public class Square   extends  Shape {

	//side 
	
	public void area()
	{
		System.out.println("Area of Square");
	}
}
