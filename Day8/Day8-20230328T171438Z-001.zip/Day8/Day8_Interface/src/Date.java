
public class Date implements IPrintable{

	@Override
	public void print() {
	System.out.println("Print method in Date Class");
		
	}
	

}
