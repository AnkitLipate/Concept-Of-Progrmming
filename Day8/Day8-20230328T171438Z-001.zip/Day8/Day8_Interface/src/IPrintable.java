
public interface IPrintable {
	//all data members are by default public final and static
	
	int abc=100;

	//methods are public abstract
	void print();//no need to write public abstract  void print();
	
}
