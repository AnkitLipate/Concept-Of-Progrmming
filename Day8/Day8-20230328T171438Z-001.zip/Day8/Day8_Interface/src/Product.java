
public class Product implements IPrintable{

	@Override
	public void print() {
		System.out.println("Print method in Product Class");	
	}

	
}
