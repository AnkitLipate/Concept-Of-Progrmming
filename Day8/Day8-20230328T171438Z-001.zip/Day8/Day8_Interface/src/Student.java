
public class Student  implements IPrintable{

	@Override
	public void print() {
		System.out.println("Print method in Student Class");
		
	}

}
